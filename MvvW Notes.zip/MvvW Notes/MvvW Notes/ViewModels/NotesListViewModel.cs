﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Windows.Input;
using System.ComponentModel;
using MvvW_Notes.ViewModels;
using MvvW_Notes.Models;

namespace MvvW_Notes.ViewModels
{
    public class FriendsListViewModel : INotifyPropertyChanged
    {
        public ObservableCollection<NotesViewModel> Friends { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        public ICommand CreateNotesCommand { protected set; get; }
        public ICommand DeleteNotesCommand { protected set; get; }
        public ICommand SaveNotesCommand { protected set; get; }
        public ICommand BackCommand { protected set; get; }
        NotesViewModel selectedNotes;

        public INavigation Navigation { get; set; }

        public NotesListViewModel()
        {
            Notes = new ObservableCollection<NotesViewModel>();
            CreateNotesCommand = new Command(CreateNotes);
            DeleteNotesCommand = new Command(DeleteNotes);
            SaveNotesCommand = new Command(SaveNotes);
            BackCommand = new Command(Back);
        }

        public NotesViewModel SelectedNotes
        {
            get { return selectedNotes; }
            set
            {
                if (selectedNotes != value)
                {
                    NotesViewModel tempNotes = value;
                    selectedNotes = null;
                    OnPropertyChanged("SelectedNotes");
                    Navigation.PushAsync(new NotesPage(tempNotes));
                }
            }
        }
        protected void OnPropertyChanged(string propNameNotes)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propNameNotes));
        }

        private void CreateNotes()
        {
            Navigation.PushAsync(new NotesPage(new NotesViewModel() { ListViewModel = this }));
        }
        private void Back()
        {
            Navigation.PopAsync();
        }
        private void SaveFriend(object notesObject)
        {
            NotesViewModel notes = notesObject as NotesViewModel;
            if (notes != null && notes.IsValid && !Notes.Contains(notes))
            {
                Notes.Add(notes);
            }
            Back();
        }
        private void DeleteFriend(object notesObject)
        {
            NotesViewModel notes = notesObject as NotesViewModel;
            if (notes != null)
            {
                Notes.Remove(notes);
            }
            Back();
        }
    }
}
