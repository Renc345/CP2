﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using MvvW_Notes.Models;

namespace MvvW_Notes.ViewModels
{
    public class NotesViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        NotesListViewModel lvm;

        public Notes Notes { get; private set; }

        public NotesViewModel()
        {
            Notes = new Notes();
        }

        public NotesListViewModel ListViewModel
        {
            get { return lvm; }
            set
            {
                if (lvm != value)
                {
                    lvm = value;
                    OnPropertyChanged("ListViewModel");
                }
            }
        }
        public string NameNotes
        {
            get { return Notes.NameNotes; }
            set
            {
                if (Notes.NameNotes != value)
                {
                    Notes.NameNotes = value;
                    OnPropertyChanged("NameNotes");
                }
            }
        }
        public string TextNotes
        {
            get { return Notes.NameNotes; }
            set
            {
                if (Notes.NameNotes != value)
                {
                    Notes.NameNotes = value;
                    OnPropertyChanged("NameNotes");
                }
            }
        }

        public bool IsValid
        {
            get
            {
                return ((!string.IsNullOrEmpty(NameNotes.Trim())) ||
                    (!string.IsNullOrEmpty(TextNotes.Trim())));
            }
        }
        protected void OnPropertyChanged(string propName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propName));
        }
    }
}
