﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MvvW_Notes.Models
{
    internal class Notes
    {
        public string NameNotes { get; set; }
        public string TextNotes { get; set; }
    }
}
